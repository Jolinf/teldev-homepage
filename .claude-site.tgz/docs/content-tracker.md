# TELDEV site: content tracker

Everything the site still needs before it can drop the remaining placeholders. Content
source for what's already filled: the old site in `teldev-homepage-main` (copy ported
2026-09-24). Tick items off as they land; when an item is filled, remove its
placeholder from the file(s) listed.

Status key: `[ ]` open · `[~]` partly in / waiting on someone · `[x]` done

## Content needed

- [ ] **1. Real photography.** No real TELDEV photos exist; the old site's images were
      stock (Unsplash) and illustrations. Photo slots still waiting (each shows an
      `ImagePlaceholder` with a note describing the shot):
  - Home hero: AI-generated placeholder in place (2026-09-24,
    `public/images/hero-engineer-client.webp`, set in `app/page.tsx`); replace with a
    real photo of the team with a client when one exists
  - About: wide team photo under the statement; `app/about/page.tsx` (`photo` prop)
  - Partnerships: event photo behind the hero copy (pass `photo={{ src, alt }}` to
    `PhotoHero`; until then the hero is a solid dark band), plus the two event
    highlights; `app/partnerships/page.tsx`
  - Work: case study image; `content/work/*.mdx`
  - Blog: article images (`image:` in each post's frontmatter) for future posts
  - Services, service pages and Contact no longer use photos (hero redesign, 2026-09-24).
- [~] **2. Founder portraits.** Joshua Ulinfun's added 2026-09-25
      (`public/team/joshua-ulinfun.webp`, set via `image` in `content/team.ts`; also used
      in his blog bylines). Consider a replacement without sunglasses and without the DHL
      sign in the background. Still needed: Olutunde Solabi, Kayode Ojedele. Use square
      photos, head and shoulders, plain background.
- [~] **3. Client / partner logos.** Bash (usebash.io) added 2026-09-24: logo in both
      strips, plus an "Our events run on Bash" section on Partnerships
      (`components/partner-spotlight.tsx`, facts in `content/partners.ts`). Before launch:
      confirm the wording ("official events & ticketing partner"; that TELDEV events are
      ticketed on Bash) and let Bash review the section.
  - Home "Trusted by" strip: `Partner B–E` still placeholders; `app/page.tsx`
  - Partnerships strip: `Partner D` still a placeholder; `app/partnerships/page.tsx`
  - To add another logo: put the SVG in `public/partners/`, add an entry like `BASH.logo`
    in `content/partners.ts`, and pass it to `LogoStrip`.
- [ ] **4. Testimonials**; two needed, real and attributable (name, role,
      organisation, permission to publish). Placeholders in `content/testimonials.ts`,
      shown on Home and Work.
- [ ] **5. Case studies**; at least one real project (problem, what we did, what
      changed, one metric). Placeholder: `content/work/cloud-migration-with-zero-downtime.mdx`
      (`placeholder: true`).
- [~] **6. Blog posts.** First real post published 2026-09-24: "Fitted but not used:
      Nigeria and the technology it already has"
      (`content/blog/nigeria-and-the-technology-it-already-has.mdx`), credited to
      Joshua Ulinfun, with an AI-generated cover image
      (`public/blog/nigeria-technology-cover.webp`; replace with a real photo if
      preferred). Posts are credited to "TELDEV Technologies" unless `author:` is set. The old site's posts lived in MongoDB (API was returning 500) and
      were never exported. The three other files in `content/blog/` are design
      samples, `draft: true`; delete them or replace them with real posts.
- [~] **7. Partnership & event details.**
  - NAMS Western Region (Nigerian Association of Microbiology Students, Western Region):
    added 2026-09-26 from instagram.com/namswrgram. Crest in both logo strips
    (`public/partners/nams-west-region.webp`, `NAMS_WR` in `content/partners.ts`); event
    card updated to the real 7th Western Region Convention ("The UNILAG Experience '26",
    University of Lagos, 24–27 September 2026), linking to their 26 August post naming
    TELDEV an official partner. Still wanted: event photos for the card.
  - University of Lagos sponsorship (`Sep 02`): **not confirmed**; confirm or remove.
- [ ] **8. Founder LinkedIn URLs.** Bios were removed from the About page cards
      (decision 2026-09-26), so only LinkedIn URLs remain; the icons link to `#` until
      they're added to `content/team.ts`.
- [ ] **9. Statement of Intent and TSIM manual**; not in the content folder. The site
      uses their wording as already ported into the old site's code; add the source
      documents to check against when they're available.
- [ ] **10. Legal documents review** (on hold, per decision 2026-09-24). Privacy Policy,
      Terms & Conditions and Cookie Policy exist as PDFs in Google Drive (all
      May 2025). Review for: NDPA 2023 compliance; Terms still mention
      "telecommunications solutions" and don't cover AI/automation work; Privacy
      Policy predates the current contact form (Microsoft Graph mailer, Vercel
      Analytics). After review, publish as pages: `/privacy` (currently
      `[Privacy policy text to be supplied]`, `noindex`), plus `/terms` and `/cookies`.

## Decisions needed

- [ ] **Illustrative figures in the decorative cards.** After the hero redesign these
      only remain on the Home hero ("Microsoft 365 migration 86%", "Ticket #2481",
      "Response in 42 minutes"; `components/hero-visual.tsx`), the placeholder case
      study ("0 hrs downtime"; `components/case-study.tsx` defaults and the MDX file)
      and the contact form's "We reply within one working day". Replace with real
      figures or remove.
- [ ] **Old-site content with no slot in the current design**; needs a design
      decision before it can go in: Mission & Vision (full text), Our Story, CEO quote
      ("Technology should not be something that people struggle to reach. We bring it
      to them."), the 8 core values, the full TSIM-based AI & Automation page (the
      detail template only has problem / what / outcomes), GitHub link
      (`github.com/TelDev-LTD`, no icon slot in the footer).
- [ ] **Leadership quotes** from the old site (CTO/COO lines) were not carried over:
      recommend one-line bios instead.
- [ ] **"24/7 technical assistance"** (old Helpdesk card) was not carried over; only
      add it back if someone actually covers out-of-hours.

## Filled from the old site (2026-09-24)

- Six services (Helpdesk Support, Network & Infrastructure, Application & Website
  Development, Cloud Solutions, IT Consulting, AI & Automation); nav, footer, contact
  form, services overview, six detail pages.
- Home hero lead (Statement of Intent wording), services intro, About hero lead
  (mission), five strategic pillars, roadmap wording.
- Founders' names and roles.
- Second phone number (+234 903 756 2951), LinkedIn and Instagram URLs, social
  profiles in structured data.
- Hero redesign (2026-09-24): one hero per page type; see `components/page-heroes.tsx`.
- Layout adjustments needed for the extra items, no visual redesign: service card grid
  is three per row on desktop (was four), and the team grid allows three founders across
  (was capped at two); both in `app/ds-components.css`.
