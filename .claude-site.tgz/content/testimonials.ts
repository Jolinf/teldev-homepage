/**
 * Placeholders; the previous copy here was invented sample quotes from the design kit.
 * Replace with real, attributable client quotes (with permission to publish).
 * See docs/content-tracker.md (item 4).
 */
export const TESTIMONIALS = [
  {
    quote: '[Client testimonial to be supplied]',
    name: '[Client name]',
    role: '[Role, organisation]',
  },
  {
    quote: '[Client testimonial to be supplied]',
    name: '[Client name]',
    role: '[Role, organisation]',
  },
];
